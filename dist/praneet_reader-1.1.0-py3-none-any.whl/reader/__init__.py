# __init__.py

# Version of the praneet-reader package
__version__ = "1.1.0"